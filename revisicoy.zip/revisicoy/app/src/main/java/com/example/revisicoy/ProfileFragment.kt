package com.example.revisicoy

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class ProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        val sharedPref = activity?.getSharedPreferences("UserProfile", Context.MODE_PRIVATE)
        val email = sharedPref?.getString("email", "N/A")
        val nim = sharedPref?.getString("nim", "N/A")
        val nama = sharedPref?.getString("nama", "N/A")
        val kelas = sharedPref?.getString("kelas", "N/A")

        view.findViewById<TextView>(R.id.emailTextView).text = email
        view.findViewById<TextView>(R.id.nimTextView).text = nim
        view.findViewById<TextView>(R.id.namaTextView).text = nama
        view.findViewById<TextView>(R.id.kelasTextView).text = kelas

        return view
    }
}
