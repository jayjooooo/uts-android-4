
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.revisicoy.Alumni
import com.example.revisicoy.R


class TambahDataFragment : Fragment() {

    private lateinit var editTextNIM: EditText
    private lateinit var editTextNama: EditText
    private lateinit var editTextTempatLahir: EditText
    private lateinit var editTextTanggalLahir: EditText
    private lateinit var editTextAlamat: EditText
    private lateinit var editTextAgama: EditText
    private lateinit var editTextTelepon: EditText
    private lateinit var editTextTahunMasuk: EditText
    private lateinit var editTextTahunLulus: EditText
    private lateinit var editTextPekerjaan: EditText
    private lateinit var editTextJabatan: EditText
    private lateinit var buttonSimpan: Button
    private lateinit var dbHelper: DatabaseHelper

    // Definisi kelas Mahasiswa di luar fungsi-fungsi
    data class Mahasiswa(
        val nim: String,
        val nama: String,
        val tempatLahir: String,
        val tanggalLahir: String,
        val alamat: String,
        val agama: String,
        val telepon: String,
        val tahunMasuk: String,
        val tahunLulus: String,
        val pekerjaan: String,
        val jabatan: String
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_tambah_data, container, false)

        // Inisialisasi view
        editTextNIM = view.findViewById(R.id.editTextNIM)
        editTextNama = view.findViewById(R.id.editTextNama)
        editTextTempatLahir = view.findViewById(R.id.editTextTempatLahir)
        editTextTanggalLahir = view.findViewById(R.id.editTextTanggalLahir)
        editTextAlamat = view.findViewById(R.id.editTextAlamat)
        editTextAgama = view.findViewById(R.id.editTextAgama)
        editTextTelepon = view.findViewById(R.id.editTextTelepon)
        editTextTahunMasuk = view.findViewById(R.id.editTextTahunMasuk)
        editTextTahunLulus = view.findViewById(R.id.editTextTahunLulus)
        editTextPekerjaan = view.findViewById(R.id.editTextPekerjaan)
        editTextJabatan = view.findViewById(R.id.editTextJabatan)

        buttonSimpan = view.findViewById(R.id.buttonSimpan)

        dbHelper = DatabaseHelper(requireContext())

        // Set listener untuk tombol
        buttonSimpan.setOnClickListener {
            simpanData()
        }

        return view
    }

    private fun simpanData() {
        val nim = editTextNIM.text.toString()
        val nama = editTextNama.text.toString()
        val tempatLahir = editTextTempatLahir.text.toString()
        val tanggalLahir = editTextTanggalLahir.text.toString()
        val alamat = editTextAlamat.text.toString()
        val agama = editTextAgama.text.toString()
        val telepon = editTextTelepon.text.toString()
        val tahunMasuk = editTextTahunMasuk.text.toString()
        val tahunLulus = editTextTahunLulus.text.toString()
        val pekerjaan = editTextPekerjaan.text.toString()
        val jabatan = editTextJabatan.text.toString()

        // Membuat objek Mahasiswa menggunakan kelas Mahasiswa yang telah didefinisikan di luar fungsi
        val alumni = Alumni(
            nim, nama, tempatLahir, tanggalLahir, alamat, agama, telepon, tahunMasuk,
            tahunLulus, pekerjaan, jabatan
        )

        val idBaru = dbHelper.tambahAlumni(alumni)

        if (idBaru != -1L) {
            Toast.makeText(requireContext(), "Data berhasil disimpan", Toast.LENGTH_SHORT).show()
            clearFields()
        } else {
            Toast.makeText(requireContext(), "Gagal menyimpan data", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearFields() {
        editTextNIM.text.clear()
        editTextNama.text.clear()
        editTextTempatLahir.text.clear()
        editTextTanggalLahir.text.clear()
        editTextAlamat.text.clear()
        editTextAgama.text.clear()
        editTextTelepon.text.clear()
        editTextTahunMasuk.text.clear()
        editTextTahunLulus.text.clear()
        editTextPekerjaan.text.clear()
        editTextJabatan.text.clear()
    }
}
