import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.revisicoy.Alumni

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, NAMA_DATABASE, null, VERSI_DATABASE) {

    companion object {
        private const val VERSI_DATABASE = 1
        private const val NAMA_DATABASE = "StudentDB"

        // Tabel dan Kolom
        private const val TABEL_ALUMNI = "alumni"
        private const val KOLOM_ID = "id"
        private const val KOLOM_NIM = "nim"
        private const val KOLOM_NAMA = "nama"
        private const val KOLOM_TEMPAT_LAHIR = "tempat_lahir"
        private const val KOLOM_TANGGAL_LAHIR = "tanggal_lahir"
        private const val KOLOM_ALAMAT = "alamat"
        private const val KOLOM_AGAMA = "agama"
        private const val KOLOM_TELEPON = "telepon"
        private const val KOLOM_TAHUN_MASUK = "tahun_masuk"
        private const val KOLOM_TAHUN_LULUS = "tahun_lulus"
        private const val KOLOM_PEKERJAAN = "pekerjaan"
        private const val KOLOM_JABATAN = "jabatan"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val BUAT_TABEL_ALUMNI = "CREATE TABLE $TABEL_ALUMNI(" +
                "$KOLOM_ID INTEGER PRIMARY KEY," +
                "$KOLOM_NIM TEXT," +
                "$KOLOM_NAMA TEXT," +
                "$KOLOM_TEMPAT_LAHIR TEXT," +
                "$KOLOM_TANGGAL_LAHIR TEXT," +
                "$KOLOM_ALAMAT TEXT," +
                "$KOLOM_AGAMA TEXT," +
                "$KOLOM_TELEPON TEXT," +
                "$KOLOM_TAHUN_MASUK TEXT," +
                "$KOLOM_TAHUN_LULUS TEXT," +
                "$KOLOM_PEKERJAAN TEXT," +
                "$KOLOM_JABATAN TEXT" + ")"
        db.execSQL(BUAT_TABEL_ALUMNI)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Hapus tabel lama jika ada
        db.execSQL("DROP TABLE IF EXISTS $TABEL_ALUMNI")
        // Buat tabel lagi
        onCreate(db)
    }

    fun tambahAlumni(alumni: Alumni): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(KOLOM_NIM, alumni.nim)
        values.put(KOLOM_NAMA, alumni.nama)
        values.put(KOLOM_TEMPAT_LAHIR, alumni.tempatLahir)
        values.put(KOLOM_TANGGAL_LAHIR, alumni.tanggalLahir)
        values.put(KOLOM_ALAMAT, alumni.alamat)
        values.put(KOLOM_AGAMA, alumni.agama)
        values.put(KOLOM_TELEPON, alumni.telepon)
        values.put(KOLOM_TAHUN_MASUK, alumni.tahunMasuk)
        values.put(KOLOM_TAHUN_LULUS, alumni.tahunLulus)
        values.put(KOLOM_PEKERJAAN, alumni.pekerjaan)
        values.put(KOLOM_JABATAN, alumni.jabatan)
        val idBaru = db.insert(TABEL_ALUMNI, null, values)
        db.close()
        return idBaru
    }

    fun getAllAlumni(): List<Alumni> {
        val daftarAlumni = mutableListOf<Alumni>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABEL_ALUMNI", null)
        cursor.use {
            if (it.moveToFirst()) {
                do {
                    val nim = it.getString(it.getColumnIndex(KOLOM_NIM))
                    val nama = it.getString(it.getColumnIndex(KOLOM_NAMA))
                    val tempatLahir = it.getString(it.getColumnIndex(KOLOM_TEMPAT_LAHIR))
                    val tanggalLahir = it.getString(it.getColumnIndex(KOLOM_TANGGAL_LAHIR))
                    val alamat = it.getString(it.getColumnIndex(KOLOM_ALAMAT))
                    val agama = it.getString(it.getColumnIndex(KOLOM_AGAMA))
                    val telepon = it.getString(it.getColumnIndex(KOLOM_TELEPON))
                    val tahunMasuk = it.getString(it.getColumnIndex(KOLOM_TAHUN_MASUK))
                    val tahunLulus = it.getString(it.getColumnIndex(KOLOM_TAHUN_LULUS))
                    val pekerjaan = it.getString(it.getColumnIndex(KOLOM_PEKERJAAN))
                    val jabatan = it.getString(it.getColumnIndex(KOLOM_JABATAN))
                    val alumni = Alumni(nim, nama, tempatLahir, tanggalLahir, alamat, agama, telepon, tahunMasuk, tahunLulus, pekerjaan, jabatan)
                    daftarAlumni.add(alumni)
                } while (it.moveToNext())
            }
        }

        return daftarAlumni
    }
}
