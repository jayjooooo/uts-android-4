package com.example.revisicoy

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AlumniDatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "AlumniDB"
        private const val TABLE_NAME = "alumni"
        const val COLUMN_ID = "_id" // Menggunakan kolom _id sebagai PRIMARY KEY
        const val COLUMN_NIM = "nim"
        const val COLUMN_NAMA = "nama"
        const val COLUMN_TEMPAT_LAHIR = "tempat_lahir"
        const val COLUMN_TANGGAL_LAHIR = "tanggal_lahir"
        const val COLUMN_ALAMAT = "alamat"
        const val COLUMN_AGAMA = "agama"
        const val COLUMN_TELEPON = "telepon"
        const val COLUMN_TAHUN_MASUK = "tahun_masuk"
        const val COLUMN_TAHUN_LULUS = "tahun_lulus"
        const val COLUMN_PEKERJAAN = "pekerjaan"
        const val COLUMN_JABATAN = "jabatan"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val CREATE_TABLE = ("CREATE TABLE $TABLE_NAME (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_NIM TEXT, " +
                "$COLUMN_NAMA TEXT, " +
                "$COLUMN_TEMPAT_LAHIR TEXT, " +
                "$COLUMN_TANGGAL_LAHIR TEXT, " +
                "$COLUMN_ALAMAT TEXT, " +
                "$COLUMN_AGAMA TEXT, " +
                "$COLUMN_TELEPON TEXT, " +
                "$COLUMN_TAHUN_MASUK TEXT, " +
                "$COLUMN_TAHUN_LULUS TEXT, " +
                "$COLUMN_PEKERJAAN TEXT, " +
                "$COLUMN_JABATAN TEXT)")
        db.execSQL(CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun addAlumni(nim: String, nama: String, tempatLahir: String, tanggalLahir: String, alamat: String, agama: String, telepon: String, tahunMasuk: String, tahunLulus: String, pekerjaan: String, jabatan: String) {
        val values = ContentValues().apply {
            put(COLUMN_NIM, nim)
            put(COLUMN_NAMA, nama)
            put(COLUMN_TEMPAT_LAHIR, tempatLahir)
            put(COLUMN_TANGGAL_LAHIR, tanggalLahir)
            put(COLUMN_ALAMAT, alamat)
            put(COLUMN_AGAMA, agama)
            put(COLUMN_TELEPON, telepon)
            put(COLUMN_TAHUN_MASUK, tahunMasuk)
            put(COLUMN_TAHUN_LULUS, tahunLulus)
            put(COLUMN_PEKERJAAN, pekerjaan)
            put(COLUMN_JABATAN, jabatan)
        }

        val db = this.writableDatabase
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    fun getAllAlumni(): Cursor? {
        val db = this.readableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_NAME", null)
    }
}
