import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.revisicoy.Alumni
import com.example.revisicoy.R

class AlumniAdapter(private val alumniList: List<Alumni>) : RecyclerView.Adapter<AlumniAdapter.AlumniViewHolder>() {

    private var onItemClickListener: ((Alumni) -> Unit)? = null

    fun setOnItemClickListener(listener: (Alumni) -> Unit) {
        onItemClickListener = listener
    }

    inner class AlumniViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewNama: TextView = itemView.findViewById(R.id.textViewNama)
        val textViewTahunLulus: TextView = itemView.findViewById(R.id.textViewTahunLulus)
        val textViewPekerjaan: TextView = itemView.findViewById(R.id.textViewPekerjaan)
        val textViewJabatan: TextView = itemView.findViewById(R.id.textViewJabatan)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlumniViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.alumni_list_item, parent, false)
        return AlumniViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: AlumniViewHolder, position: Int) {
        val currentItem = alumniList[position]

        // Bind data to views
        holder.textViewNama.text = currentItem.nama
        holder.textViewTahunLulus.text = "Tahun Lulus: ${currentItem.tahunLulus}"
        holder.textViewPekerjaan.text = "Pekerjaan: ${currentItem.pekerjaan}"
        holder.textViewJabatan.text = "Jabatan: ${currentItem.jabatan}"

        // Set click listener
        holder.itemView.setOnClickListener {
            onItemClickListener?.invoke(currentItem)
        }
    }

    override fun getItemCount() = alumniList.size
}
