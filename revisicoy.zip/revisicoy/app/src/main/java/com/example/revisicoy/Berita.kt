package com.example.revisicoy

import android.os.Parcel
import android.os.Parcelable

data class Berita(
    val judul: String,
    val deskripsi: String
) : Parcelable {
    // Implementasi describeContents() yang sederhana
    override fun describeContents(): Int {
        return 0
    }

    // Implementasi writeToParcel() untuk menulis objek ke parcel
    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(judul)
        parcel.writeString(deskripsi)
    }

    companion object CREATOR : Parcelable.Creator<Berita> {
        // Implementasi createFromParcel() untuk membaca objek dari parcel
        override fun createFromParcel(parcel: Parcel): Berita {
            return Berita(parcel.readString()!!, parcel.readString()!!)
        }

        // Implementasi newArray() untuk membuat array objek dari parcel
        override fun newArray(size: Int): Array<Berita?> {
            return arrayOfNulls(size)
        }
    }
}
