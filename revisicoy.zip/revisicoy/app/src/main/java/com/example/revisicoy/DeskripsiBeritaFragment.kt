package com.example.revisicoy

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class DeskripsiBeritaFragment : Fragment() {

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_deskripsi_berita, container, false)
        val judulTextView: TextView = view.findViewById(R.id.textViewJudulBerita)
        val deskripsiTextView: TextView = view.findViewById(R.id.textViewDeskripsiBerita)

        // Ambil argumen yang diteruskan ke fragment
        val berita = arguments?.getParcelable<Berita>("berita")
        judulTextView.text = berita?.judul
        deskripsiTextView.text = berita?.deskripsi

        return view
    }

    companion object {
        // Fungsi untuk membuat instance baru dari fragment dengan argumen
        fun newInstance(berita: Berita): DeskripsiBeritaFragment {
            val fragment = DeskripsiBeritaFragment()
            val args = Bundle()
            args.putParcelable("berita", berita)
            fragment.arguments = args
            return fragment
        }
    }
}
