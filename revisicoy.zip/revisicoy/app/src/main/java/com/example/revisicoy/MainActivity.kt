package com.example.revisicoy

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val emailEditText: EditText = findViewById(R.id.editTextEmail)
        val nimEditText: EditText = findViewById(R.id.editTextNim)
        val namaEditText: EditText = findViewById(R.id.editTextNama)
        val kelasEditText: EditText = findViewById(R.id.editTextKelas)
        val loginButton: Button = findViewById(R.id.buttonLogin)

        loginButton.setOnClickListener {
            // Ambil data dari inputan pengguna
            val email = emailEditText.text.toString()
            val nim = nimEditText.text.toString()
            val nama = namaEditText.text.toString()
            val kelas = kelasEditText.text.toString()

            // Simpan data pengguna ke SharedPreferences
            val sharedPref = getSharedPreferences("UserProfile", Context.MODE_PRIVATE)
            with(sharedPref.edit()) {
                putString("email", email)
                putString("nim", nim)
                putString("nama", nama)
                putString("kelas", kelas)
                apply()
            }

            // Intent untuk berpindah dari MainActivity ke HomeActivity
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
        }
    }
}
