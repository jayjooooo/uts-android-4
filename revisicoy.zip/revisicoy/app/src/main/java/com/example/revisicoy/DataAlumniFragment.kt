
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.revisicoy.AlumniDetailActivity
import com.example.revisicoy.R

class DataAlumniFragment : Fragment() {

    private lateinit var recyclerViewAlumni: RecyclerView
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_data_alumni, container, false)

        // Inisialisasi RecyclerView
        recyclerViewAlumni = view.findViewById(R.id.recyclerViewAlumni)
        recyclerViewAlumni.layoutManager = LinearLayoutManager(requireContext())

        // Inisialisasi DatabaseHelper
        dbHelper = DatabaseHelper(requireContext())

        // Mendapatkan data alumni dari database
        val listAlumni = dbHelper.getAllAlumni()

        // Mengatur adapter untuk RecyclerView
        val adapter = AlumniAdapter(listAlumni)
        recyclerViewAlumni.adapter = adapter

        // Set item click listener
        adapter.setOnItemClickListener { alumni ->
            // Navigate to detail page
            val intent = Intent(requireContext(), AlumniDetailActivity::class.java)
            intent.putExtra("ALUMNI_ID", alumni.nim) // Pass any necessary data to the detail page
            startActivity(intent)
        }

        return view
    }
}
