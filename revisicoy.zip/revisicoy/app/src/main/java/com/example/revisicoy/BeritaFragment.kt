package com.example.revisicoy

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ListView
import androidx.fragment.app.Fragment

class BeritaFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate layout untuk fragment ini
        val view = inflater.inflate(R.layout.fragment_berita, container, false)

        val listView: ListView = view.findViewById(R.id.listViewBerita)

        val beritaList = listOf(
            Berita("Luhut Tolak Tawaran Jadi Menteri Prabowo, Pilih Jadi Ini", "Luhut Binsar Pandjaitan mengatakan dirinya menolak tawaran menjadi menteri di pemerintahan presidenterpilihPrabowo Subianto. \n" +
                    "\"Beliau (Prabowo) sudah minta. Saya sudah sampaikan, kalau untuk jadi menteri saya tidak (bisa),\" kata Luhut kepada wartawan di Kura Kura Bali, dikutip Minggu (19/5/2024)"),
            Berita("Kronologi Pemerintahan Jokowi Bongkar Pasang Aturan Impor, Ada Apa?", "Pemerintahan Presiden Joko Widodo (Jokowi) kembali melakukan perombakan aturan dan kebijakan impor. Dalam revisi terbaru ini, pemerintah memutuskan melonggarkan impor yang sebelumnya sempat diperketat."),
            Berita("Bos BPJS Kesehatan Buka Suara Soal Penghapusan Sistem Kelas 1, 2, 3", "Belakangan heboh mengenai rencana pemerintah untuk menghapus kelas 1, 2, dan 3 Badan Penyelenggara Jaminan Sosial (BPJS) Kesehatan. Hal ini seiring dengan hendak dilakukan standarisasi kelas melalui sistem Kelas Rawat Inap Standar (KRIS) di seluruh Indonesia..")
        )

        // Buat adapter kustom
        val adapter = BeritaAdapter(requireContext(), beritaList)

        // Set adapter ke ListView
        listView.adapter = adapter

        // Set listener untuk menangani klik pada item
        listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val berita = beritaList[position]
            val deskripsiFragment = DeskripsiBeritaFragment.newInstance(berita)

            // Ganti fragment saat item di ListView diklik
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, deskripsiFragment)
                .addToBackStack(null)
                .commit()
        }

        return view
    }
}
