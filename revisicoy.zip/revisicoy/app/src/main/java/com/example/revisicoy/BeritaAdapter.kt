package com.example.revisicoy

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class BeritaAdapter(context: Context, private val data: List<Berita>) : ArrayAdapter<Berita>(context, 0, data) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var listItemView = convertView
        if (listItemView == null) {
            listItemView = LayoutInflater.from(context).inflate(R.layout.list_item_berita, parent, false)
        }

        val currentBerita = getItem(position)

        val judulTextView: TextView = listItemView!!.findViewById(R.id.textViewJudulBerita)
        judulTextView.text = currentBerita?.judul

        val deskripsiTextView: TextView = listItemView.findViewById(R.id.textViewDeskripsiBerita)
        deskripsiTextView.text = currentBerita?.deskripsi

        return listItemView
    }
}
